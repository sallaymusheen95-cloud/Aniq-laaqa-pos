# Aniq Laaqa Pvt Ltd — Grocery POS v1

A beginner-friendly, mobile-first, offline-first POS prototype. It supports products, a sales cart, cash received, change due, screen receipts, sales history, stock reduction, CSV export, and JSON backup/restore.

## Important limitations
- Data is stored in the browser's local storage on this device only. It is not synced to another phone or cloud.
- Do not clear Chrome site data. Export backups frequently. A lost/damaged phone may mean lost sales data.
- This is a prototype, not a certified accounting, tax, or inventory system. Test carefully before using for real customer transactions.
- The first sample products/prices are examples. Edit or delete them and enter the shop's actual prices before selling.
- Service workers (offline PWA support) require HTTPS or localhost. Opening index.html directly may run the basic app but will not enable install/offline caching.

## Easiest setup using only an Android smartphone

### Option A — Recommended: GitHub Pages (free HTTPS hosting)
1. On your phone, open Chrome and create/sign in to a GitHub account at https://github.com.
2. Create a new **public** repository named `aniq-laaqa-pos`. Do not add a README if you plan to upload these files as-is (optional).
3. Upload `index.html`, `app.js`, `manifest.json`, and `sw.js` from this project folder to the repository root. You can use GitHub's web interface in Chrome; if the page is cramped, turn on Chrome's **Desktop site**.
4. In the repository, open **Settings → Pages**.
5. Under build/deployment, choose **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish. Open the provided `https://YOUR-USERNAME.github.io/aniq-laaqa-pos/` address.
7. In Chrome, open the app menu (⋮) and choose **Install app** or **Add to Home screen**.
8. Open it once while online so it caches the files. Then test Airplane mode. The app should still open and let you create sales offline.

A public repository means the source code is public. Do not put customer personal data, real sales records, passwords, or private keys in the repository. The app's sales data is kept in the browser, not in these code files.

### Option B — Local test
1. Extract the ZIP on a computer or use an Android code editor that can preview local HTML.
2. Open `index.html` in a browser. The basic cashier UI may work, but service-worker install/offline support will not work from a `file://` URL.
3. For a real PWA, use Option A or another HTTPS static host.

## First use
1. Go to **Products**.
2. Edit/delete sample items, and add the shop's products, selling prices, and opening stock.
3. Go to **Sell**, tap products to add them to the bill, and use +/− to change quantities.
4. Enter discount if needed and the cash the customer gives you.
5. Check the displayed change. **Complete sale & show receipt** is enabled only when cash covers the total.
6. Go to **Sales** to review the day's sales, export CSV, or download a JSON backup.

## Test checklist
- Total Rs. 800; received Rs. 1,000 → change Rs. 200.
- Total Rs. 800; received Rs. 500 → says Rs. 300 more needed; cannot complete.
- Exact cash → change Rs. 0.
- Complete a sale → sale appears in Sales and stock is reduced.
- Reload the page → products and sales remain on that same browser/device.
- With the app already loaded/cached, switch on Airplane mode and test a new sale.
- Export a backup and keep it somewhere safe outside the phone.

## File map
- `index.html` — app layout and styles
- `app.js` — cart, calculations, products, sales, receipts, backup/export
- `manifest.json` — installable PWA metadata
- `sw.js` — offline app-shell cache

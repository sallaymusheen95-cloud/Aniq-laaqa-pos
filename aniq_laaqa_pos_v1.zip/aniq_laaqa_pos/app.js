/* Aniq Laaqa POS — local-first prototype. No server/account is used. */
const DB_KEY = "aniqLaaqaPos_v1";
const money = n => "Rs. " + Number(n || 0).toLocaleString("en-LK",{minimumFractionDigits:2,maximumFractionDigits:2});
const todayKey = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; };
const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
const initialData = () => ({
  products:[
    {id:uid(),name:"Rice (1 kg)",price:250,stock:20},
    {id:uid(),name:"Sugar (1 kg)",price:300,stock:15},
    {id:uid(),name:"Milk powder",price:1200,stock:8},
    {id:uid(),name:"Bread",price:180,stock:12}
  ], sales:[]
});
let db = loadDB();
let cart = [];
let lastReceipt = null;
function loadDB(){ try { const v=JSON.parse(localStorage.getItem(DB_KEY)); if(v && Array.isArray(v.products) && Array.isArray(v.sales)) return v; } catch(e){} return initialData(); }
function saveDB(){ try{localStorage.setItem(DB_KEY,JSON.stringify(db));return true}catch(e){alert("Could not save. Device storage may be full or disabled. Export a backup and free storage.");return false;} }
const $ = id => document.getElementById(id);
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function setTab(name){document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===name));document.querySelectorAll(".tab-page").forEach(s=>s.classList.toggle("hidden",s.id!==name));if(name==="products")renderManageProducts();if(name==="sales")renderSales();}
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>setTab(b.dataset.tab)));
function renderProductButtons(){
 const q=$("productSearch").value.trim().toLowerCase();
 const list=db.products.filter(p=>p.name.toLowerCase().includes(q));
 $("productButtons").innerHTML=list.length?list.map(p=>`<button class="product" data-add="${p.id}"><strong>${escapeHtml(p.name)}</strong><span>${money(p.price)}</span><small class="muted">${p.stock} in stock</small></button>`).join(""):`<div class="empty">No matching products.</div>`;
 document.querySelectorAll("[data-add]").forEach(b=>b.addEventListener("click",()=>addToCart(b.dataset.add)));
}
$("productSearch").addEventListener("input",renderProductButtons);
function addToCart(id){const p=db.products.find(x=>x.id===id);if(!p)return;const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id:p.id,name:p.name,price:Number(p.price),qty:1});renderCart();}
function cartTotal(){return cart.reduce((s,x)=>s+x.price*x.qty,0);}
function discountValue(){return Math.max(0,Number($("discount").value)||0);}
function finalTotal(){return Math.max(0,cartTotal()-Math.min(discountValue(),cartTotal()));}
function renderCart(){
 $("cart").innerHTML=cart.length?cart.map(x=>`<div class="cart-row"><div><strong>${escapeHtml(x.name)}</strong><div class="muted">${money(x.price)} each · ${money(x.price*x.qty)}</div><div class="qty" style="margin-top:7px"><button class="small-btn" data-minus="${x.id}" aria-label="Decrease quantity">−</button><strong>${x.qty}</strong><button class="small-btn" data-plus="${x.id}" aria-label="Increase quantity">+</button><button class="danger" data-remove="${x.id}" aria-label="Remove item">×</button></div></div></div>`).join(""):`<div class="empty">No items yet. Tap a product to begin.</div>`;
 document.querySelectorAll("[data-minus]").forEach(b=>b.addEventListener("click",()=>changeQty(b.dataset.minus,-1)));
 document.querySelectorAll("[data-plus]").forEach(b=>b.addEventListener("click",()=>changeQty(b.dataset.plus,1)));
 document.querySelectorAll("[data-remove]").forEach(b=>b.addEventListener("click",()=>{cart=cart.filter(x=>x.id!==b.dataset.remove);renderCart();}));
 const sub=cartTotal(), total=finalTotal(), received=Math.max(0,Number($("cashReceived").value)||0);
 $("subtotal").textContent=money(sub);$("grandTotal").textContent=money(total);
 const box=$("changeBox");box.classList.toggle("owed",received<total);
 $("changeAmount").textContent=received<total?`${money(total-received)} more needed`:money(received-total);
 $("completeSale").disabled=!cart.length||received<total||total<=0;
 renderProductButtons();
}
function changeQty(id,delta){const x=cart.find(x=>x.id===id);if(!x)return;x.qty+=delta;if(x.qty<=0)cart=cart.filter(i=>i.id!==id);renderCart();}
$("discount").addEventListener("input",renderCart);$("cashReceived").addEventListener("input",renderCart);
$("clearCart").addEventListener("click",()=>{if(cart.length&&!confirm("Clear this bill?"))return;cart=[];$("discount").value="0";$("cashReceived").value="";renderCart();});
$("productForm").addEventListener("submit",e=>{
 e.preventDefault();const name=$("newName").value.trim(),price=Number($("newPrice").value),stock=Number($("newStock").value);
 if(!name||!Number.isFinite(price)||price<=0||!Number.isInteger(stock)||stock<0){alert("Enter a product name, a price above zero, and whole-number stock.");return;}
 if(db.products.some(p=>p.name.toLowerCase()===name.toLowerCase())){alert("A product with this name already exists. Use a unique name.");return;}
 db.products.push({id:uid(),name,price,stock});if(!saveDB())return;e.target.reset();$("newStock").value="0";renderManageProducts();renderProductButtons();alert("Product saved on this device.");
});
function renderManageProducts(){
 $("productCount").textContent=`${db.products.length} products`;
 $("manageProducts").innerHTML=db.products.length?db.products.map(p=>`<div class="cart-row"><div><strong>${escapeHtml(p.name)}</strong><div class="muted">${money(p.price)} · Stock: ${p.stock}</div></div><div class="row"><button class="small-btn" data-edit="${p.id}">Edit</button><button class="danger" data-delete="${p.id}">Delete</button></div></div>`).join(""):`<div class="empty">No products yet.</div>`;
 document.querySelectorAll("[data-edit]").forEach(b=>b.addEventListener("click",()=>editProduct(b.dataset.edit)));
 document.querySelectorAll("[data-delete]").forEach(b=>b.addEventListener("click",()=>deleteProduct(b.dataset.delete)));
}
function editProduct(id){const p=db.products.find(x=>x.id===id);if(!p)return;const name=prompt("Product name:",p.name);if(name===null)return;const price=prompt("Selling price in Rs.:",p.price);if(price===null)return;const stock=prompt("Stock units:",p.stock);if(stock===null)return;const n=name.trim(),pr=Number(price),st=Number(stock);if(!n||!Number.isFinite(pr)||pr<=0||!Number.isInteger(st)||st<0){alert("Invalid values. No changes saved.");return;}if(db.products.some(x=>x.id!==id&&x.name.toLowerCase()===n.toLowerCase())){alert("Another product already has that name.");return;}Object.assign(p,{name:n,price:pr,stock:st});saveDB();renderManageProducts();renderProductButtons();renderCart();}
function deleteProduct(id){const p=db.products.find(x=>x.id===id);if(!p)return;if(!confirm(`Delete "${p.name}" from the product list? Past receipts remain.`))return;db.products=db.products.filter(x=>x.id!==id);cart=cart.filter(x=>x.id!==id);saveDB();renderManageProducts();renderProductButtons();renderCart();}
$("completeSale").addEventListener("click",()=>{
 const total=finalTotal(),received=Number($("cashReceived").value);
 if(!cart.length||!Number.isFinite(received)||received<total||total<=0)return;
 const insufficient=cart.filter(x=>{const p=db.products.find(p=>p.id===x.id);return !p||p.stock<x.qty;});
 if(insufficient.length){const msg=insufficient.map(x=>`${x.name}: available ${db.products.find(p=>p.id===x.id)?.stock??0}, requested ${x.qty}`).join("\n");if(!confirm("Stock is lower than the bill:\n"+msg+"\n\nComplete sale anyway?"))return;}
 const sale={id:uid(),date:new Date().toISOString(),items:cart.map(x=>({...x})),subtotal:cartTotal(),discount:Math.min(discountValue(),cartTotal()),total,received,change:received-total};
 sale.items.forEach(x=>{const p=db.products.find(p=>p.id===x.id);if(p)p.stock=Math.max(0,p.stock-x.qty);});
 db.sales.unshift(sale);if(!saveDB())return;lastReceipt=sale;renderReceipt(sale);$("receiptModal").classList.remove("hidden");cart=[];$("cashReceived").value="";$("discount").value="0";renderCart();
});
function renderReceipt(s){
 $("receiptContent").innerHTML=`<div style="text-align:center"><strong>ANIQ LAAQA PVT LTD</strong><div class="muted">Grocery sales receipt</div><div class="muted">${new Date(s.date).toLocaleString()}</div><div class="muted">Receipt: ${escapeHtml(s.id.slice(-10).toUpperCase())}</div></div><hr>${s.items.map(x=>`<div class="receipt-line"><span>${escapeHtml(x.name)} × ${x.qty}<br><small class="muted">${money(x.price)} each</small></span><strong>${money(x.price*x.qty)}</strong></div>`).join("")}<hr><div class="receipt-line"><span>Subtotal</span><strong>${money(s.subtotal)}</strong></div><div class="receipt-line"><span>Discount</span><strong>− ${money(s.discount)}</strong></div><div class="receipt-line"><strong>TOTAL</strong><strong>${money(s.total)}</strong></div><div class="receipt-line"><span>Cash received</span><strong>${money(s.received)}</strong></div><div class="receipt-line"><strong>CHANGE</strong><strong>${money(s.change)}</strong></div><hr><div style="text-align:center" class="muted">Thank you! Please visit again.</div>`;
}
$("closeReceipt").addEventListener("click",()=>$("receiptModal").classList.add("hidden"));
$("newSale").addEventListener("click",()=>$("receiptModal").classList.add("hidden"));
function renderSales(){
 const today=db.sales.filter(s=>s.date.slice(0,10)===todayKey());
 $("todayTotal").textContent=money(today.reduce((n,s)=>n+s.total,0));$("todayCount").textContent=today.length;
 $("salesList").innerHTML=db.sales.length?db.sales.slice(0,100).map(s=>`<div class="cart-row"><div><strong>${money(s.total)}</strong><div class="muted">${new Date(s.date).toLocaleString()} · ${s.items.reduce((n,x)=>n+x.qty,0)} items</div></div><button class="small-btn" data-receipt="${s.id}">View</button></div>`).join(""):`<div class="empty">No sales recorded yet.</div>`;
 document.querySelectorAll("[data-receipt]").forEach(b=>b.addEventListener("click",()=>{const s=db.sales.find(x=>x.id===b.dataset.receipt);if(s){renderReceipt(s);$("receiptModal").classList.remove("hidden");}}));
}
$("backupBtn").addEventListener("click",()=>downloadFile(`aniq-laaqa-backup-${todayKey()}.json`,JSON.stringify({app:"Aniq Laaqa POS",version:1,exportedAt:new Date().toISOString(),...db},null,2),"application/json"));
$("exportCsv").addEventListener("click",()=>{const rows=[["Receipt ID","Date","Items","Subtotal LKR","Discount LKR","Total LKR","Cash received LKR","Change LKR"],...db.sales.map(s=>[s.id,new Date(s.date).toLocaleString(),s.items.map(i=>`${i.name} x${i.qty}`).join("; "),s.subtotal,s.discount,s.total,s.received,s.change])];const csv=rows.map(row=>row.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(",")).join("\r\n");downloadFile(`aniq-laaqa-sales-${todayKey()}.csv`,"\ufeff"+csv,"text/csv;charset=utf-8");});
function downloadFile(name,content,type){const blob=new Blob([content],{type}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$("restoreFile").addEventListener("change",async e=>{const file=e.target.files[0];if(!file)return;try{const parsed=JSON.parse(await file.text());if(!Array.isArray(parsed.products)||!Array.isArray(parsed.sales))throw Error("Backup must include products and sales arrays.");if(!confirm("This will replace all current products and sales on this device. Continue?"))return;db={products:parsed.products,sales:parsed.sales};cart=[];if(saveDB()){renderProductButtons();renderCart();renderManageProducts();renderSales();alert("Backup restored.");}}catch(err){alert("Could not restore backup: "+err.message)}finally{e.target.value="";}});
function registerSW(){if("serviceWorker" in navigator && location.protocol!=="file:"){navigator.serviceWorker.register("./sw.js").catch(()=>{});}}
function connection(){const online=navigator.onLine;$("connection").textContent=online?"Online · saved on device":"Offline mode";$("connection").classList.toggle("off",!online);}
window.addEventListener("online",connection);window.addEventListener("offline",connection);
saveDB();renderProductButtons();renderCart();renderManageProducts();renderSales();connection();registerSW();
